/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package utils;

/**
 *
 * @author marcel
 */
public class constants {

    public static final String IMAGESDIR = "/var/webapp/lab1/images/";
    public static final String APPDIR = "/var/webapp/lab1";   
    //public static final String IMAGESDIR = "C:/Users/Max Pasten/lab1/images/";
    //public static final String APPDIR = "C:/Users/Max Pasten/lab1";   
}
